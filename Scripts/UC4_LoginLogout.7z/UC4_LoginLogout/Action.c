Action()
{
	
	lr_start_transaction("UC4_LoginLogout");
	
		OpenWebPage();
		
		lr_think_time(5);

		LogIn();
		
		lr_think_time(5);
		
		LogOut();
	
	lr_end_transaction("UC4_LoginLogout", LR_AUTO);

		
	return 0;
}
